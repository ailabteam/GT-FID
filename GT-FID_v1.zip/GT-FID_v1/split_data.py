import os
import pickle
from collections import Counter
from sklearn.model_selection import train_test_split
import numpy as np
import json

def filter_small_classes(sequences, labels, min_samples=2):
    label_counts = Counter(labels)
    keep_labels = {lab for lab, cnt in label_counts.items() if cnt >= min_samples}
    filtered_seqs = []
    filtered_labs = []
    for seq, lab in zip(sequences, labels):
        if lab in keep_labels:
            filtered_seqs.append(seq)
            filtered_labs.append(lab)
    print(f"[INFO] Filtered dataset: {len(filtered_seqs)} samples after removing classes with < {min_samples} samples")
    return filtered_seqs, filtered_labs

def main():
    data_dir = "preprocessed_adfa"
    seq_path = os.path.join(data_dir, "sequences.pkl")
    lab_path = os.path.join(data_dir, "labels.pkl")
    label_dict_path = os.path.join(data_dir, "label_dict.json")

    with open(seq_path, "rb") as f:
        sequences = pickle.load(f)
    with open(lab_path, "rb") as f:
        labels = pickle.load(f)
    with open(label_dict_path, "r") as f:
        label_dict = json.load(f)

    # Filter classes có ít hơn 2 samples
    sequences, labels = filter_small_classes(sequences, labels, min_samples=2)

    sequences = np.array(sequences, dtype=object)
    labels = np.array(labels)

    # Tách train 70%, val 15%, test 15% với stratify
    seq_train, seq_temp, lab_train, lab_temp = train_test_split(
        sequences, labels, test_size=0.3, random_state=42, stratify=labels
    )
    seq_val, seq_test, lab_val, lab_test = train_test_split(
        seq_temp, lab_temp, test_size=0.5, random_state=42, stratify=lab_temp
    )

    print(f"[INFO] Train: {len(seq_train)}, Val: {len(seq_val)}, Test: {len(seq_test)}")

    # Lưu dữ liệu ra file
    os.makedirs(data_dir, exist_ok=True)
    with open(os.path.join(data_dir, "train.pkl"), "wb") as f:
        pickle.dump((seq_train, lab_train), f)
    with open(os.path.join(data_dir, "val.pkl"), "wb") as f:
        pickle.dump((seq_val, lab_val), f)
    with open(os.path.join(data_dir, "test.pkl"), "wb") as f:
        pickle.dump((seq_test, lab_test), f)
    with open(os.path.join(data_dir, "label_dict.json"), "w") as f:
        json.dump(label_dict, f)

    print(f"[INFO] Saved train/val/test splits to {data_dir}/")

if __name__ == "__main__":
    main()

