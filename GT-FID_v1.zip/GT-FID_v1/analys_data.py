import pickle
from collections import Counter

def analyze_label_distribution(label_file_path):
    with open(label_file_path, "rb") as f:
        labels = pickle.load(f)

    label_counts = Counter(labels)
    print(f"Total distinct labels: {len(label_counts)}")

    # In tất cả nhãn và số lượng sample
    print("Label counts (label: count):")
    for label, count in label_counts.most_common():
        print(f"{label}: {count}")

    # Lọc nhãn có sample > 100
    labels_over_100 = {label: count for label, count in label_counts.items() if count > 100}
    print(f"\nNumber of labels with more than 100 samples: {len(labels_over_100)}")
    print("Labels with >100 samples:")
    for label, count in labels_over_100.items():
        print(f"{label}: {count}")

if __name__ == "__main__":
    analyze_label_distribution("preprocessed_adfa/labels.pkl")

