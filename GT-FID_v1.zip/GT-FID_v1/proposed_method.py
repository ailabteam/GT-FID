import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import torch.optim as optim

from torch_geometric.nn import GCNConv, global_mean_pool

import random
import numpy as np

# ========== Model GT-FID ==========
class GTFID(nn.Module):
    def __init__(self, 
                 num_syscalls,   # vocabulary size for syscalls (for embeddings)
                 embed_dim=64, 
                 lstm_hidden=128, 
                 gnn_hidden=128,
                 gnn_layers=2,
                 fusion_hidden=192,
                 num_classes=10):
        super(GTFID, self).__init__()
        # Embedding for syscalls (for LSTM input)
        self.embedding = nn.Embedding(num_syscalls, embed_dim, padding_idx=0)
        
        # LSTM branch
        self.lstm = nn.LSTM(embed_dim, lstm_hidden, batch_first=True)
        
        # GNN branch (GCN with global pooling)
        self.convs = nn.ModuleList()
        self.convs.append(GCNConv(embed_dim, gnn_hidden))
        for _ in range(gnn_layers - 1):
            self.convs.append(GCNConv(gnn_hidden, gnn_hidden))
        
        # Classifier after fusion
        # Fusion size = lstm_hidden + gnn_hidden
        self.classifier = nn.Sequential(
            nn.Linear(lstm_hidden + gnn_hidden, fusion_hidden),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(fusion_hidden, num_classes)
        )
        
    def forward(self, seq, seq_len, node_feats, edge_index, batch_graph):
        """
        seq: LongTensor [B, T] system call sequences (integers)
        seq_len: list/array length B, lengths of sequences (for packing)
        node_feats: FloatTensor [N_nodes, embed_dim] node features for GNN (here embedding of nodes)
        edge_index: LongTensor [2, N_edges] edge connectivity for GNN
        batch_graph: LongTensor [N_nodes] batch vector for GNN nodes to graph ids
        
        Returns:
            out: [B, num_classes]
        """
        # ---- LSTM branch ----
        embedded = self.embedding(seq)  # [B, T, embed_dim]
        packed = nn.utils.rnn.pack_padded_sequence(embedded, seq_len.cpu(), batch_first=True, enforce_sorted=False)
        packed_out, (hn, cn) = self.lstm(packed)
        lstm_feat = hn[-1]  # take last layer hidden state [B, lstm_hidden]
        
        # ---- GNN branch ----
        x = node_feats
        for conv in self.convs:
            x = conv(x, edge_index)
            x = F.relu(x)
        gnn_feat = global_mean_pool(x, batch_graph)  # [B, gnn_hidden]
        
        # ---- Fusion & Classifier ----
        fused = torch.cat([lstm_feat, gnn_feat], dim=1)  # [B, lstm_hidden + gnn_hidden]
        out = self.classifier(fused)
        return out

# ========== Dummy Dataset ==========

class DummyGTIDataset(Dataset):
    def __init__(self, num_samples=1000, max_seq_len=20, num_syscalls=50):
        self.num_samples = num_samples
        self.max_seq_len = max_seq_len
        self.num_syscalls = num_syscalls
        self.num_classes = 10
        
        # Generate random data for demo
        self.data = []
        for _ in range(num_samples):
            seq_len = random.randint(5, max_seq_len)
            seq = torch.randint(1, num_syscalls, (seq_len,), dtype=torch.long)
            label = random.randint(0, self.num_classes-1)
            
            # For graph, create node features = embeddings of unique syscalls in seq
            unique_calls = torch.unique(seq)
            node_feats = unique_calls.float().unsqueeze(1)  # Just dummy feature = call id as float
            
            # Create edges between consecutive unique calls (chain)
            if len(unique_calls) > 1:
                edges = []
                for i in range(len(unique_calls)-1):
                    edges.append([i, i+1])
                    edges.append([i+1, i])  # undirected
                edge_index = torch.tensor(edges, dtype=torch.long).t()
            else:
                edge_index = torch.empty((2, 0), dtype=torch.long)
            
            self.data.append({
                'seq': seq,
                'seq_len': seq_len,
                'node_feats': node_feats,
                'edge_index': edge_index,
                'label': label
            })
        
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        return self.data[idx]

def collate_fn(batch):
    """
    batch: list of dicts with keys: seq, seq_len, node_feats, edge_index, label
    
    Returns batched versions:
    - seq_padded [B, max_len]
    - seq_lens [B]
    - node_feats_cat [N_nodes, feat_dim]
    - edge_index_cat [2, total_edges]
    - batch_graph [N_nodes] (mapping node to graph idx)
    - labels [B]
    """
    batch_size = len(batch)
    seq_lens = torch.tensor([item['seq_len'] for item in batch], dtype=torch.long)
    max_len = max(seq_lens)
    seq_padded = torch.zeros((batch_size, max_len), dtype=torch.long)
    for i, item in enumerate(batch):
        seq_padded[i, :item['seq_len']] = item['seq']
    
    # Concatenate node features and edge_index, adjust edge_index for batching
    node_feats_list = []
    edge_index_list = []
    batch_graph = []
    node_offset = 0
    for i, item in enumerate(batch):
        node_feats_list.append(item['node_feats'])
        batch_graph.append(torch.full((item['node_feats'].size(0),), i, dtype=torch.long))
        
        # Shift edge_index by node_offset
        if item['edge_index'].numel() > 0:
            edge_index_list.append(item['edge_index'] + node_offset)
        node_offset += item['node_feats'].size(0)
    
    node_feats_cat = torch.cat(node_feats_list, dim=0).float()
    if edge_index_list:
        edge_index_cat = torch.cat(edge_index_list, dim=1)
    else:
        edge_index_cat = torch.empty((2,0), dtype=torch.long)
    batch_graph = torch.cat(batch_graph, dim=0)
    
    labels = torch.tensor([item['label'] for item in batch], dtype=torch.long)
    
    return seq_padded, seq_lens, node_feats_cat, edge_index_cat, batch_graph, labels

# ========== Training and evaluation ==========
def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss = 0
    correct = 0
    total = 0
    for seq, seq_len, node_feats, edge_index, batch_graph, labels in loader:
        seq, seq_len = seq.to(device), seq_len.to(device)
        node_feats, edge_index, batch_graph = node_feats.to(device), edge_index.to(device), batch_graph.to(device)
        labels = labels.to(device)
        
        optimizer.zero_grad()
        outputs = model(seq, seq_len, node_feats, edge_index, batch_graph)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item() * seq.size(0)
        _, preds = outputs.max(1)
        correct += preds.eq(labels).sum().item()
        total += seq.size(0)
    return running_loss/total, correct/total

def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for seq, seq_len, node_feats, edge_index, batch_graph, labels in loader:
            seq, seq_len = seq.to(device), seq_len.to(device)
            node_feats, edge_index, batch_graph = node_feats.to(device), edge_index.to(device), batch_graph.to(device)
            labels = labels.to(device)
            
            outputs = model(seq, seq_len, node_feats, edge_index, batch_graph)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item() * seq.size(0)
            _, preds = outputs.max(1)
            correct += preds.eq(labels).sum().item()
            total += seq.size(0)
    return running_loss/total, correct/total

# ========== Main ==========
def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("[INFO] Using device:", device)
    
    # Hyperparameters
    num_syscalls = 50
    batch_size = 64
    epochs = 20
    lr = 0.001
    
    # Dataset & Loader
    dataset = DummyGTIDataset(num_samples=2000, max_seq_len=25, num_syscalls=num_syscalls)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)
    
    # Model
    model = GTFID(num_syscalls=num_syscalls, num_classes=10).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    best_val_acc = 0
    
    for epoch in range(1, epochs+1):
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        
        print(f"[Epoch {epoch}] Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
        print(f"           Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}")
        
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), "best_gtfid_model.pt")
            print("[INFO] Model saved at epoch", epoch)

if __name__ == "__main__":
    main()

